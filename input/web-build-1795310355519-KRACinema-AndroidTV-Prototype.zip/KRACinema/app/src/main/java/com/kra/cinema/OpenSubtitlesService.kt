package com.kra.cinema

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.ZipInputStream

class OpenSubtitlesService(private val apiKey: String) {
    suspend fun search(title: String, year: String, languages: String): List<SubtitleResult> = withContext(Dispatchers.IO) {
        val query = URLEncoder.encode(title, "UTF-8")
        val url = URL("https://api.opensubtitles.com/api/v1/subtitles?query=$query&languages=$languages" + if (year.isNotBlank()) "&year=$year" else "")
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.setRequestProperty("Api-Key", apiKey)
            connection.setRequestProperty("User-Agent", "KRACinema v0.2.0")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("OpenSubtitles HTTP $code: $body")
            val data = JSONObject(body).optJSONArray("data") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until data.length()) {
                    val attrs = data.optJSONObject(i)?.optJSONObject("attributes") ?: continue
                    val files = attrs.optJSONArray("files") ?: continue
                    for (j in 0 until files.length()) {
                        val f = files.optJSONObject(j) ?: continue
                        val id = f.optInt("file_id")
                        if (id > 0) add(SubtitleResult(id, attrs.optString("language"), attrs.optString("release"), attrs.optInt("download_count"), f.optString("file_name", "subtitle.srt")))
                    }
                }
            }.take(30)
        } finally { connection.disconnect() }
    }

    suspend fun download(context: Context, fileId: Int): Uri = withContext(Dispatchers.IO) {
        val connection = (URL("https://api.opensubtitles.com/api/v1/download").openConnection() as HttpURLConnection)
        val link: String
        try {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.setRequestProperty("Api-Key", apiKey)
            connection.setRequestProperty("User-Agent", "KRACinema v0.2.0")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write("{\"file_id\":$fileId}".toByteArray()) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("OpenSubtitles download HTTP $code: $body")
            link = JSONObject(body).optString("link")
            if (link.isBlank()) error("لم يرجع مزود الترجمة رابط تنزيل")
        } finally { connection.disconnect() }

        val response = (URL(link).openConnection() as HttpURLConnection)
        try {
            response.connectTimeout = 15000
            response.readTimeout = 30000
            val bytes = response.inputStream.use { it.readBytes() }
            val targetDir = File(context.cacheDir, "subtitles").apply { mkdirs() }
            val fileName = "subtitle_${fileId}.srt"
            val out = File(targetDir, fileName)
            if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()) {
                ZipInputStream(bytes.inputStream()).use { zip ->
                    var entry = zip.nextEntry
                    var saved = false
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name.substringAfterLast('.').lowercase() in listOf("srt", "ass", "ssa", "vtt")) {
                            out.outputStream().use { zip.copyTo(it) }
                            saved = true
                            break
                        }
                        entry = zip.nextEntry
                    }
                    if (!saved) error("ملف ZIP لا يحتوي على ترجمة مدعومة")
                }
            } else out.writeBytes(bytes)
            Uri.fromFile(out)
        } finally { response.disconnect() }
    }
}
