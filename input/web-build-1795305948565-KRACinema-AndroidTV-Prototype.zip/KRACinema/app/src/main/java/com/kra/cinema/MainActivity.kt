package com.kra.cinema

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

private val Night = Color(0xFF090B12)
private val Panel = Color(0xFF171B29)
private val Violet = Color(0xFF8B5CF6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinemaApp() }
    }
}

private data class VideoFile(val title: String, val uri: Uri)

@Composable
private fun CinemaApp() {
    val context = LocalContext.current
    var videos by remember { mutableStateOf(emptyList<VideoFile>()) }
    var selected by remember { mutableStateOf<VideoFile?>(null) }
    var status by remember { mutableStateOf("اختر مجلد الهاردسك لعرض ملفات الفيديو") }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    treeUri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                val root = DocumentFile.fromTreeUri(context, treeUri)
                val found = root?.listFiles()?.filter { file ->
                    file.isFile && (file.type?.startsWith("video/") == true ||
                        file.name?.substringAfterLast('.', "")?.lowercase()?.let { it in
                        listOf("mp4", "mkv", "avi", "mov", "m4v", "webm", "ts") } == true)
                }?.map { file -> VideoFile(file.name ?: "Video", file.uri) }.orEmpty()
                videos = found
                status = if (found.isEmpty()) "لم يتم العثور على فيديوهات في هذا المجلد" else "تم العثور على ${found.size} ملف فيديو"
            } catch (e: Exception) {
                status = "تعذر قراءة المجلد: ${e.localizedMessage ?: "خطأ غير معروف"}"
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Night, surface = Panel, primary = Violet)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171329), Night)))) {
            if (selected != null) {
                VideoScreen(video = selected!!, onBack = { selected = null })
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 54.dp, vertical = 34.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("KRA", color = Violet, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text(" CINEMA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("ANDROID TV · تجربة أولية", color = Color.LightGray, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(38.dp))
                    Text("سينما بيتك", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("أفلامك ومسلسلاتك في مكان واحد", color = Color(0xFFB9B6C8), fontSize = 17.sp)
                    Spacer(Modifier.height(28.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ActionTile("اختيار الهاردسك USB", "تصفح ملفات الفيديو", true) { folderPicker.launch(null) }
                        ActionTile("مكتبة الشبكة", "قريباً · SMB / Media Server", false) { status = "ميزة ربط مكتبة الشبكة ستضاف في النسخة التالية" }
                    }
                    Spacer(Modifier.height(22.dp))
                    Text(status, color = Color(0xFFB9B6C8), fontSize = 14.sp)
                    Spacer(Modifier.height(24.dp))
                    Text(if (videos.isEmpty()) "مكتبتك" else "ملفات الفيديو (${videos.size})", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(14.dp))
                    if (videos.isEmpty()) {
                        Box(Modifier.fillMaxWidth().weight(1f).background(Panel.copy(alpha = .72f), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("▶", color = Violet, fontSize = 42.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("لا توجد ملفات مضافة بعد", color = Color.White, fontSize = 18.sp)
                                Text("اضغط على اختيار الهاردسك USB للبدء", color = Color.LightGray, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(videos) { video ->
                                VideoTile(video.title) { selected = video }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("نسخة تجريبية 0.1.0 · تشغيل الملفات يعتمد على دعم التلفزيون للترميز", color = Color(0xFF777487), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, primary: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = Modifier.width(260.dp).height(92.dp).onFocusChanged { focused = it.isFocused },
        shape = RoundedCornerShape(16.dp),
        color = if (focused) Violet else Panel,
        border = if (focused) BorderStroke(2.dp, Color.White) else BorderStroke(1.dp, Color(0xFF343448))
    ) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 15.dp), verticalArrangement = Arrangement.Center) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Color(0xFFD0CDE0), fontSize = 11.sp)
        }
    }
}

@Composable
private fun VideoTile(title: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, modifier = Modifier.width(190.dp).height(132.dp).onFocusChanged { focused = it.isFocused },
        color = if (focused) Color(0xFF393052) else Panel,
        shape = RoundedCornerShape(14.dp),
        border = if (focused) BorderStroke(2.dp, Violet) else BorderStroke(1.dp, Color(0xFF343448))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text("▶", color = Violet, fontSize = 25.sp)
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
        }
    }
}

@Composable
private fun VideoScreen(video: VideoFile, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع", color = Color.White) }
            Text(video.title, color = Color.White, fontSize = 14.sp, maxLines = 1)
        }
        AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().weight(1f))
    }
}
