# KRA Cinema — Android TV Prototype

## Included in this revision

- Android TV-oriented dark navy / blue UI. No purple color constants or purple focus states.
- TMDB trending/search catalog, show/movie details, TV season-one episode metadata, and similar-movie lists.
- USB / local-folder browsing through Android Storage Access Framework. Network folders can be opened when an installed Android document provider exposes them (for example, a compatible SMB provider).
- Direct HLS / MP4 URL playback through AndroidX Media3 (including the HLS module).
- Audio and embedded subtitle track selection from tracks actually exposed by Media3.
- Manual subtitle import (`.srt`, `.ass`, `.ssa`, `.vtt`) and OpenSubtitles.com API search/download.
- TMDB Read Access Token and OpenSubtitles API Key are entered in Settings and stored in app-private SharedPreferences; no credentials are hard-coded.

## API setup

1. Create a TMDB API Read Access Token and enter it in Settings. The app uses TMDB v3 endpoints with a Bearer token.
2. Create an OpenSubtitles.com API key and enter it in Settings. Subtitle search uses `/api/v1/subtitles`; downloads use `/api/v1/download`.
3. The app searches Arabic and English subtitles (`ara,eng`).

## Build

Run from this directory with Android SDK + Gradle 8.9 and JDK 17+:

```bash
gradle assembleDebug
```

Expected APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations to validate on the target TCL TV

- This workspace did not include a Gradle wrapper or Android SDK. Build and device validation must be run in AndroidForge / a configured Android build environment.
- Network-folder access depends on a document provider installed on the TV; Android's picker does not implement SMB itself.
- Episode metadata comes from TMDB; the app does not provide copyrighted video streams. Select a local file or a stream URL you are authorized to use.
- Track selection depends on the audio/text tracks exposed by the media container and decoder. External subtitle attachment is implemented for the selected media item.
- This is a prototype: no account system, remote library server, background downloads, or automatic subtitle matching by file hash yet.


## UI language and typography
- The home screen includes an Arabic / English language switch.
- Arabic uses right-to-left layout; English uses left-to-right layout.
- The selected language is saved locally and restored on the next launch.
- TMDB requests follow the selected language (`ar-SA` or `en-US`).
- The interface uses Android's `sans-serif` family as a clean Apple-like system sans-serif fallback. Apple SF Pro is not bundled because it is an Apple proprietary font and is not available as a licensed Android system font.


## TMDB connection and Android TV Back behavior

- Open Settings → TMDB API, then use **Open TMDB API Settings** to visit https://www.themoviedb.org/settings/api.
- Create/copy the **API Read Access Token** (Bearer token) and paste it into the app. The settings page URL itself is not an API key.
- Use **Fetch sample movie: Oppenheimer** to make a real TMDB search request and populate the catalog with its localized title, overview, rating, release year, poster and backdrop when TMDB provides them.
- The Android TV remote Back key navigates from player → previous page, settings/search/detail → home. At the home screen Back is consumed and does not close the app.
