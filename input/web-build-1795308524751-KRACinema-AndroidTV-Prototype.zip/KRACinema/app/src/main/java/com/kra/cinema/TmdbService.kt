package com.kra.cinema

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class TmdbService(private val accessToken: String) {
    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val connection = URL("https://api.themoviedb.org/3$path").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000
            connection.setRequestProperty("Authorization", "Bearer $accessToken")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("TMDB HTTP $code: $body")
            JSONObject(body)
        } finally { connection.disconnect() }
    }

    suspend fun trending(): List<CatalogItem> = get("/trending/all/week?language=ar-SA").items()
    suspend fun search(query: String): List<CatalogItem> {
        val q = URLEncoder.encode(query, "UTF-8")
        val movies = get("/search/movie?query=$q&language=ar-SA").items()
        val shows = get("/search/tv?query=$q&language=ar-SA").items()
        return (movies + shows).sortedByDescending { it.rating }
    }
    suspend fun similar(item: CatalogItem): List<CatalogItem> {
        val type = if (item.isSeries) "tv" else "movie"
        return get("/$type/${item.id}/similar?language=ar-SA&page=1").items()
    }
    suspend fun episodes(item: CatalogItem, season: Int = 1): List<EpisodeItem> {
        val json = get("/tv/${item.id}/season/$season?language=ar-SA")
        val array = json.optJSONArray("episodes") ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val e = array.optJSONObject(index) ?: return@mapNotNull null
            EpisodeItem(e.optInt("episode_number"), e.optString("name", "الحلقة ${index + 1}"), e.optString("overview"), e.optString("still_path").takeIf { it != "null" && it.isNotBlank() })
        }
    }

    private fun JSONObject.items(): List<CatalogItem> {
        val array = optJSONArray("results") ?: return emptyList()
        return (0 until array.length()).mapNotNull { index ->
            val o = array.optJSONObject(index) ?: return@mapNotNull null
            val type = o.optString("media_type", if (o.has("first_air_date")) "tv" else "movie")
            if (type != "movie" && type != "tv") return@mapNotNull null
            val date = o.optString(if (type == "tv") "first_air_date" else "release_date")
            CatalogItem(
                id = o.optInt("id"),
                title = o.optString(if (type == "tv") "name" else "title").ifBlank { o.optString("original_name", "عمل بدون عنوان") },
                overview = o.optString("overview"),
                posterPath = o.optString("poster_path").takeIf { it != "null" && it.isNotBlank() },
                backdropPath = o.optString("backdrop_path").takeIf { it != "null" && it.isNotBlank() },
                rating = o.optDouble("vote_average", 0.0),
                year = date.take(4),
                mediaType = type
            )
        }
    }
}
