package com.kra.cinema

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private val Night = Color(0xFF070B12)
private val Panel = Color(0xFF111C2A)
private val Panel2 = Color(0xFF17283A)
private val Blue = Color(0xFF168BDF)
private val Cyan = Color(0xFF36C7E8)
private val Muted = Color(0xFF9EADBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinemaApp() }
    }
}

private data class VideoFile(val title: String, val uri: Uri)
private data class PlaybackSource(val title: String, val uri: Uri)
private data class TrackOption(val group: Tracks.Group, val index: Int, val label: String, val language: String?)

@Composable
private fun CinemaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("kra_cinema_settings", 0) }
    var tmdbToken by remember { mutableStateOf(prefs.getString("tmdb_token", "") ?: "") }
    var subtitlesKey by remember { mutableStateOf(prefs.getString("opensubtitles_key", "") ?: "") }
    var videos by remember { mutableStateOf(emptyList<VideoFile>()) }
    var selected by remember { mutableStateOf<CatalogItem?>(null) }
    var playing by remember { mutableStateOf<PlaybackSource?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var urlDialog by remember { mutableStateOf(false) }
    var searchDialog by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    var catalog by remember { mutableStateOf(DemoCatalog.items) }
    var searchResults by remember { mutableStateOf<List<CatalogItem>>(emptyList()) }
    var similar by remember { mutableStateOf<List<CatalogItem>>(emptyList()) }
    var episodes by remember { mutableStateOf<List<EpisodeItem>>(emptyList()) }
    var status by remember { mutableStateOf("أدخل بيانات TMDB لعرض أحدث الأفلام والمسلسلات") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val root = DocumentFile.fromTreeUri(context, treeUri)
                val found = root?.listFiles()?.filter { file ->
                    file.isFile && (file.type?.startsWith("video/") == true || file.name?.substringAfterLast('.', "")?.lowercase() in listOf("mp4", "mkv", "avi", "mov", "m4v", "webm", "ts"))
                }?.map { VideoFile(it.name ?: "Video", it.uri) }.orEmpty()
                videos = found
                status = if (found.isEmpty()) "لم نعثر على فيديوهات في المجلد المحدد" else "تم العثور على ${found.size} ملف فيديو"
            } catch (e: Exception) { status = "تعذر قراءة المجلد: ${e.localizedMessage}" }
        }
    }

    fun refreshCatalog() {
        if (tmdbToken.isBlank()) { status = "أضف TMDB Read Access Token من الإعدادات لتفعيل الكتالوج"; return }
        scope.launch {
            loading = true
            try {
                catalog = TmdbService(tmdbToken).trending()
                status = "تم تحديث الكتالوج من TMDB"
            } catch (e: Exception) { status = "تعذر الاتصال بـ TMDB: ${e.message}" }
            loading = false
        }
    }

    fun openItem(item: CatalogItem) {
        selected = item
        similar = emptyList()
        episodes = if (item.isDemo && item.isSeries) listOf(
            EpisodeItem(1, "البداية", "حلقة تجريبية لعرض شكل قائمة الحلقات.", null),
            EpisodeItem(2, "خط جديد", "حلقة تجريبية ثانية.", null),
            EpisodeItem(3, "داخل المؤسسة", "حلقة تجريبية ثالثة.", null)
        ) else emptyList()
    }

    LaunchedEffect(tmdbToken) { if (tmdbToken.isNotBlank()) refreshCatalog() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Cyan, background = Night, surface = Panel, onPrimary = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10243A), Night)))) {
            when {
                playing != null -> PlayerScreen(
                    source = playing!!,
                    apiKey = subtitlesKey,
                    onBack = { playing = null },
                    onStatus = { status = it }
                )
                settingsOpen -> SettingsScreen(
                    tmdbToken = tmdbToken,
                    subtitlesKey = subtitlesKey,
                    onSave = { tmdb, subs ->
                        tmdbToken = tmdb.trim(); subtitlesKey = subs.trim()
                        prefs.edit().putString("tmdb_token", tmdbToken).putString("opensubtitles_key", subtitlesKey).apply()
                        settingsOpen = false
                    },
                    onBack = { settingsOpen = false }
                )
                selected != null -> DetailsScreen(
                    item = selected!!,
                    similar = similar,
                    episodes = episodes,
                    loading = loading,
                    onBack = { selected = null },
                    onPlay = { playing = PlaybackSource(selected!!.title, it) },
                    onSelectSimilar = { openItem(it) },
                    onLoadDetails = {
                        val item = selected!!
                        scope.launch {
                            loading = true
                            try {
                                if (!item.isDemo) {
                                    if (item.isSeries) episodes = TmdbService(tmdbToken).episodes(item)
                                    else similar = TmdbService(tmdbToken).similar(item)
                                }
                            } catch (e: Exception) { status = "تعذر تحميل التفاصيل: ${e.message}" }
                            loading = false
                        }
                    },
                    localVideos = videos
                )
                else -> HomeScreen(
                    catalog = catalog,
                    videos = videos,
                    status = status,
                    loading = loading,
                    onSelect = { openItem(it) },
                    onUsb = { folderPicker.launch(null) },
                    onNetwork = { folderPicker.launch(null) },
                    onStream = { urlDialog = true },
                    onSettings = { settingsOpen = true },
                    onSearch = { searchDialog = true },
                    onPlayLocal = { playing = PlaybackSource(it.title, it.uri) }
                )
            }
        }
    }

    if (urlDialog) {
        var url by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { urlDialog = false }, containerColor = Panel,
            title = { Text("تشغيل رابط بث", color = Color.White) },
            text = { OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("رابط الفيديو HLS / MP4") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (url.startsWith("http://") || url.startsWith("https://")) { playing = PlaybackSource("بث مباشر", Uri.parse(url)); urlDialog = false } }) { Text("تشغيل") } },
            dismissButton = { TextButton(onClick = { urlDialog = false }) { Text("إلغاء") } })
    }
    if (searchDialog) {
        var query by remember { mutableStateOf(searchText) }
        AlertDialog(onDismissRequest = { searchDialog = false }, containerColor = Panel,
            title = { Text("البحث في TMDB", color = Color.White) },
            text = { OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("اسم الفيلم أو المسلسل") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                searchText = query; searchDialog = false
                if (tmdbToken.isNotBlank() && query.isNotBlank()) scope.launch {
                    loading = true
                    try { searchResults = TmdbService(tmdbToken).search(query); catalog = searchResults }
                    catch (e: Exception) { status = "فشل البحث: ${e.message}" }
                    loading = false
                }
            }) { Text("بحث") } }, dismissButton = { TextButton(onClick = { searchDialog = false }) { Text("إلغاء") } })
    }

}

@Composable
private fun HomeScreen(
    catalog: List<CatalogItem>, videos: List<VideoFile>, status: String, loading: Boolean,
    onSelect: (CatalogItem) -> Unit, onUsb: () -> Unit, onNetwork: () -> Unit,
    onStream: () -> Unit, onSettings: () -> Unit, onSearch: () -> Unit, onPlayLocal: (VideoFile) -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 42.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("KRA", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text(" CINEMA", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onSearch) { Text("⌕  البحث", color = Color.White) }
            TextButton(onClick = onSettings) { Text("⚙  الإعدادات", color = Color.White) }
        }
        Spacer(Modifier.height(24.dp))
        val hero = catalog.firstOrNull()
        if (hero != null) {
            Box(Modifier.fillMaxWidth().height(300.dp).background(Panel, RoundedCornerShape(22.dp))) {
                hero.backdropUrl?.let { AsyncImage(model = it, contentDescription = hero.title, modifier = Modifier.fillMaxSize()) }
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Night.copy(alpha = .96f), Night.copy(alpha = .62f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).widthIn(max = 620.dp).padding(28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (hero.isDemo) "عرض تجريبي · بيانات مؤقتة" else if (hero.isSeries) "مسلسل مميز" else "فيلم مميز", color = Cyan, fontSize = 14.sp)
                    Text(hero.title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("★ ${"%.1f".format(hero.rating)}   ${hero.year}   ${if (hero.isSeries) "مسلسل" else "فيلم"}", color = Color.White, fontSize = 15.sp)
                    Text(hero.overview.ifBlank { "اكتشف تفاصيل العمل ومعلوماته وحلقاته أو الأعمال المشابهة." }, color = Color(0xFFDCE7F2), maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Button(onClick = { onSelect(hero) }) { Text("التفاصيل") }
                }
            }
        } else {
            Box(Modifier.fillMaxWidth().height(220.dp).background(Panel, RoundedCornerShape(22.dp)).padding(28.dp), contentAlignment = Alignment.CenterStart) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سينما بيتك", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Text("أفلامك ومسلسلاتك في مكان واحد", color = Muted, fontSize = 18.sp)
                    Text(if (loading) "جارٍ تحميل الكتالوج…" else status, color = Cyan, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text(if (catalog.firstOrNull()?.isDemo == true) "أحدث الأفلام والمسلسلات · بيانات مؤقتة" else "أحدث الأفلام والمسلسلات", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (catalog.isEmpty()) Text("ستظهر الأعمال هنا بعد إضافة TMDB Read Access Token من الإعدادات.", color = Muted)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(catalog, key = { "${it.mediaType}-${it.id}" }) { item -> CatalogCard(item, onClick = { onSelect(item) }) }
        }
        Spacer(Modifier.height(24.dp))
        Text("مصادر المشاهدة", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile("USB / التخزين المحلي", "اختيار مجلد الفيديو", onUsb, Modifier.weight(1f))
            ActionTile("مكتبة الشبكة", "فتح مزود ملفات الشبكة", onNetwork, Modifier.weight(1f))
            ActionTile("رابط بث مباشر", "HLS / MP4 عبر الإنترنت", onStream, Modifier.weight(1f))
        }
        if (videos.isNotEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text("ملفاتك المحلية (${videos.size})", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(videos) { video -> ActionTile(video.title, "تشغيل الملف", { onPlayLocal(video) }, Modifier.width(230.dp)) }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("بيانات الأعمال والتقييمات والصور عبر TMDB · تشغيل الفيديو عبر Media3", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CatalogCard(item: CatalogItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, modifier = Modifier.width(150.dp).height(245.dp).onFocusChanged { focused = it.isFocused },
        color = Panel, shape = RoundedCornerShape(12.dp), border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) Cyan else Color(0xFF29435A))) {
        Column {
            Box(Modifier.weight(1f).fillMaxWidth().background(Panel2)) {
                item.posterUrl?.let { AsyncImage(model = it, contentDescription = item.title, modifier = Modifier.fillMaxSize()) }
                Text("★ ${"%.1f".format(item.rating)}", Modifier.align(Alignment.BottomStart).padding(7.dp).background(Night.copy(alpha = .85f), RoundedCornerShape(8.dp)).padding(horizontal = 7.dp, vertical = 4.dp), color = Color(0xFFFFD45A), fontSize = 11.sp)
            }
            Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.year} · ${if (item.isSeries) "مسلسل" else "فيلم"}", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, modifier = modifier.height(88.dp).onFocusChanged { focused = it.isFocused }, shape = RoundedCornerShape(14.dp),
        color = if (focused) Color(0xFF123F66) else Panel, border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) Cyan else Color(0xFF2A4055))) {
        Column(Modifier.padding(horizontal = 15.dp, vertical = 12.dp), verticalArrangement = Arrangement.Center) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun DetailsScreen(
    item: CatalogItem, similar: List<CatalogItem>, episodes: List<EpisodeItem>, loading: Boolean,
    onBack: () -> Unit, onPlay: (Uri) -> Unit, onSelectSimilar: (CatalogItem) -> Unit,
    onLoadDetails: () -> Unit, localVideos: List<VideoFile>
) {
    LaunchedEffect(item.id) { onLoadDetails() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(34.dp)) {
        TextButton(onClick = onBack) { Text("‹  رجوع", color = Color.White) }
        Box(Modifier.fillMaxWidth().height(260.dp).background(Panel, RoundedCornerShape(18.dp))) {
            item.backdropUrl?.let { AsyncImage(model = it, contentDescription = item.title, modifier = Modifier.fillMaxSize()) }
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Night.copy(alpha = .97f), Night.copy(alpha = .58f), Color.Transparent))))
            Column(Modifier.align(Alignment.CenterStart).widthIn(max = 650.dp).padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(item.title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                if (item.isDemo) Text("بيانات تجريبية مؤقتة · سيتم استبدالها ببيانات TMDB بعد إضافة المفتاح", color = Color(0xFFFFC66D), fontSize = 12.sp)
                Text("★ ${"%.1f".format(item.rating)}   ${item.year}   ${if (item.isSeries) "مسلسل" else "فيلم"}", color = Cyan)
                Text(item.overview.ifBlank { "لا يوجد وصف متاح لهذا العمل." }, color = Color.White, maxLines = 4, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(22.dp))
        if (item.isSeries) {
            Text("الموسم الأول · الحلقات", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (item.isDemo) Text("هذه حلقات توضيحية وليست بيانات فعلية.", color = Color(0xFFFFC66D), fontSize = 11.sp)
            if (loading) Text("جارٍ تحميل الحلقات…", color = Muted)
            if (episodes.isEmpty() && !loading) Text("لا توجد حلقات محملة. تحقق من اتصال TMDB.", color = Muted)
            episodes.forEach { episode ->
                val episodeTag = "S01E${episode.number.toString().padStart(2, '0')}"
                val matchingVideo = localVideos.firstOrNull { it.title.contains(episodeTag, ignoreCase = true) || it.title.contains("الحلقة ${episode.number}") }
                Surface(onClick = { matchingVideo?.let { onPlay(it.uri) } }, enabled = matchingVideo != null, color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (matchingVideo != null) "▶" else "${episode.number}", color = if (matchingVideo != null) Cyan else Muted, fontSize = 22.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("الحلقة ${episode.number}: ${episode.name}", color = Color.White, fontWeight = FontWeight.Bold)
                            Text(episode.overview.ifBlank { if (matchingVideo != null) "ملف محلي مطابق" else "بيانات الحلقة من TMDB · أضف ملفاً باسم S01E${episode.number.toString().padStart(2, '0')} لتشغيلها مباشرة" }, color = Muted, maxLines = 2, fontSize = 12.sp)
                        }
                    }
                }
            }
            Text("ملاحظة: TMDB يوفّر بيانات الحلقات فقط؛ مصدر الفيديو يُختار من ملفاتك أو رابط البث.", color = Muted, fontSize = 11.sp)
        } else {
            Text("أفلام مشابهة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (item.isDemo) Text("ستظهر الاقتراحات الحقيقية بعد ربط TMDB.", color = Muted, fontSize = 11.sp)
            if (loading) Text("جارٍ تحميل الاقتراحات…", color = Muted)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(similar, key = { it.id }) { CatalogCard(it) { onSelectSimilar(it) } } }
        }
    }
}

@Composable
private fun SettingsScreen(tmdbToken: String, subtitlesKey: String, onSave: (String, String) -> Unit, onBack: () -> Unit) {
    var tmdb by remember { mutableStateOf(tmdbToken) }
    var subtitles by remember { mutableStateOf(subtitlesKey) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(42.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onBack) { Text("‹  رجوع", color = Color.White) }
        Text("إعدادات الربط", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("TMDB — بيانات الأفلام والمسلسلات والتقييمات", color = Cyan, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = tmdb, onValueChange = { tmdb = it }, modifier = Modifier.fillMaxWidth(), label = { Text("TMDB API Read Access Token") }, singleLine = true)
        Text("OpenSubtitles — البحث عن الترجمات وتنزيلها", color = Cyan, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = subtitles, onValueChange = { subtitles = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OpenSubtitles API Key") }, singleLine = true)
        Text("تُحفظ المفاتيح محلياً على الجهاز. لا تضع مفاتيحك داخل ملفات المشروع أو GitHub.", color = Muted, fontSize = 12.sp)
        Button(onClick = { onSave(tmdb, subtitles) }) { Text("حفظ الإعدادات") }
    }
}

@Composable
private fun PlayerScreen(source: PlaybackSource, apiKey: String, onBack: () -> Unit, onStatus: (String) -> Unit) {
    val context = LocalContext.current
    var player by remember(source.uri) { mutableStateOf<ExoPlayer?>(null) }
    var tracks by remember { mutableStateOf(emptyList<TrackOption>()) }
    var showAudio by remember { mutableStateOf(false) }
    var showSubtitles by remember { mutableStateOf(false) }
    var showSubtitleSearch by remember { mutableStateOf(false) }
    var showManualLanguage by remember { mutableStateOf(false) }
    var manualSubtitleLanguage by remember { mutableStateOf("ara") }
    var subtitleResults by remember { mutableStateOf(emptyList<SubtitleResult>()) }
    var subtitleQuery by remember { mutableStateOf(source.title) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            attachSubtitle(player, source.uri, uri, manualSubtitleLanguage)
            onStatus("تمت إضافة ملف الترجمة")
        }
    }

    DisposableEffect(source.uri) {
        val exo = ExoPlayer.Builder(context).build()
        exo.setMediaItem(MediaItem.fromUri(source.uri)); exo.prepare(); exo.playWhenReady = true
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onTracksChanged(currentTracks: Tracks) {
                tracks = currentTracks.groups.flatMap { group ->
                    if (group.type != C.TRACK_TYPE_AUDIO && group.type != C.TRACK_TYPE_TEXT) emptyList()
                    else (0 until group.length).filter { group.isTrackSupported(it) }.map { index ->
                        val format = group.getTrackFormat(index)
                        val lang = format.language
                        TrackOption(group, index, "${if (group.type == C.TRACK_TYPE_AUDIO) "صوت" else "ترجمة"} · ${lang ?: "غير محدد"} · ${format.label ?: "مسار ${index + 1}"}", lang)
                    }
                }
            }
        }
        exo.addListener(listener)
        player = exo
        onDispose { exo.removeListener(listener); exo.release(); player = null }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع", color = Color.White) }
            Text(source.title, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
            TextButton(onClick = { showAudio = true }) { Text("الصوت", color = Cyan) }
            TextButton(onClick = { showSubtitles = true }) { Text("الترجمة", color = Cyan) }
        }
        player?.let { exo -> AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exo; useController = true } }, modifier = Modifier.fillMaxSize()) }
    }

    if (showAudio) TrackDialog("اختيار الدبلجة الصوتية", tracks.filter { it.group.type == C.TRACK_TYPE_AUDIO }, onDismiss = { showAudio = false }, onChoose = { option ->
        player?.let { exo -> exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_AUDIO).addOverride(androidx.media3.common.TrackSelectionOverride(option.group.mediaTrackGroup, listOf(option.index))).build() }
        showAudio = false
    })
    if (showSubtitles) AlertDialog(onDismissRequest = { showSubtitles = false }, containerColor = Panel,
        title = { Text("الترجمة", color = Color.White) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("المسارات المضمنة: ${tracks.count { it.group.type == C.TRACK_TYPE_TEXT }}", color = Muted)
            TextButton(onClick = { player?.let { exo -> exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }; showSubtitles = false }) { Text("إيقاف الترجمة") }
            TextButton(onClick = { showSubtitles = false; showSubtitleSearch = true }) { Text("البحث عن ترجمة عبر API") }
            TextButton(onClick = { showSubtitles = false; showManualLanguage = true }) { Text("رفع ملف ترجمة من الجهاز") }
            tracks.filter { it.group.type == C.TRACK_TYPE_TEXT }.forEach { option -> TextButton(onClick = {
                player?.let { exo -> exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).addOverride(androidx.media3.common.TrackSelectionOverride(option.group.mediaTrackGroup, listOf(option.index))).build() }
                showSubtitles = false
            }) { Text(option.label) } }
        } }, confirmButton = { TextButton(onClick = { showSubtitles = false }) { Text("إغلاق") } })

    if (showManualLanguage) AlertDialog(onDismissRequest = { showManualLanguage = false }, containerColor = Panel,
        title = { Text("لغة ملف الترجمة", color = Color.White) },
        text = { Column {
            TextButton(onClick = { manualSubtitleLanguage = "ara"; showManualLanguage = false; subtitlePicker.launch(arrayOf("application/x-subrip", "text/plain", "application/octet-stream", "text/vtt")) }) { Text("العربية") }
            TextButton(onClick = { manualSubtitleLanguage = "eng"; showManualLanguage = false; subtitlePicker.launch(arrayOf("application/x-subrip", "text/plain", "application/octet-stream", "text/vtt")) }) { Text("English") }
        } }, confirmButton = { TextButton(onClick = { showManualLanguage = false }) { Text("إلغاء") } })

    if (showSubtitleSearch) Dialog(onDismissRequest = { showSubtitleSearch = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(.82f).heightIn(max = 560.dp), color = Panel, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("البحث عن ترجمة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = subtitleQuery, onValueChange = { subtitleQuery = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم الفيلم أو المسلسل") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = apiKey.isNotBlank() && !busy, onClick = {
                        scope.launch {
                            busy = true
                            try { subtitleResults = OpenSubtitlesService(apiKey).search(subtitleQuery, "", "ara,eng"); onStatus("نتائج الترجمة: ${subtitleResults.size}") }
                            catch (e: Exception) { onStatus("فشل البحث عن الترجمة: ${e.message}") }
                            busy = false
                        }
                    }) { Text(if (busy) "جارٍ البحث…" else "بحث عربي / إنجليزي") }
                    TextButton(onClick = { showSubtitleSearch = false }) { Text("إغلاق") }
                }
                if (apiKey.isBlank()) Text("أضف OpenSubtitles API Key من الإعدادات أولاً.", color = Color(0xFFFFC66D))
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                    subtitleResults.forEach { result ->
                        Surface(onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val uri = OpenSubtitlesService(apiKey).download(context, result.fileId)
                                    attachSubtitle(player, source.uri, uri, result.language)
                                    onStatus("تم تنزيل الترجمة وإضافتها")
                                    showSubtitleSearch = false
                                } catch (e: Exception) { onStatus("تعذر تنزيل الترجمة: ${e.message}") }
                                busy = false
                            }
                        }, color = Panel2, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("${result.language.uppercase()} · ${result.fileName}", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("${result.release} · ${result.downloads} تنزيل", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackDialog(title: String, options: List<TrackOption>, onDismiss: () -> Unit, onChoose: (TrackOption) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = Color.White) },
        text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
            if (options.isEmpty()) Text("لا توجد مسارات متاحة لهذا الملف.", color = Muted)
            options.forEach { option -> TextButton(onClick = { onChoose(option) }) { Text(option.label, color = Color.White) } }
        } }, confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } })
}

private fun attachSubtitle(player: ExoPlayer?, videoUri: Uri, subtitleUri: Uri, language: String) {
    val mime = when (subtitleUri.lastPathSegment?.substringAfterLast('.', "")?.lowercase()) {
        "ass" -> MimeTypes.TEXT_SSA
        "ssa" -> MimeTypes.TEXT_SSA
        "vtt" -> MimeTypes.TEXT_VTT
        else -> MimeTypes.APPLICATION_SUBRIP
    }
    val config = MediaItem.SubtitleConfiguration.Builder(subtitleUri).setMimeType(mime).setLanguage(language).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
    player?.let { exo ->
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        exo.setMediaItem(MediaItem.Builder().setUri(videoUri).setSubtitleConfigurations(listOf(config)).build())
        exo.prepare()
        exo.playWhenReady = true
    }
}
