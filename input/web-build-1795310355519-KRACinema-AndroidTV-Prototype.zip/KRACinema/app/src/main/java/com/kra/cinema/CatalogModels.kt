package com.kra.cinema

data class CatalogItem(
    val id: Int,
    val title: String,
    val overview: String,
    val posterPath: String?,
    val backdropPath: String?,
    val rating: Double,
    val year: String,
    val mediaType: String,
    val isDemo: Boolean = false
) {
    val isSeries: Boolean get() = mediaType == "tv"
    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
    val backdropUrl: String? get() = backdropPath?.let { "https://image.tmdb.org/t/p/w1280$it" }
}

data class SubtitleResult(
    val fileId: Int,
    val language: String,
    val release: String,
    val downloads: Int,
    val fileName: String
)

data class EpisodeItem(
    val number: Int,
    val name: String,
    val overview: String,
    val stillPath: String?
)


object DemoCatalog {
    val items = listOf(
        CatalogItem(872585, "أوبنهايمر", "قصة العالم الذي قاد تطوير أول قنبلة ذرية.", null, null, 8.2, "2023", "movie", true),
        CatalogItem(693134, "Dune: Part Two", "تستمر رحلة بول أتريدس في عالم أراكيس.", null, null, 8.3, "2024", "movie", true),
        CatalogItem(414906, "The Batman", "يواجه باتمان الفساد والجريمة في مدينة غوثام.", null, null, 7.7, "2022", "movie", true),
        CatalogItem(0, "The Blue Road", "عنصر مسلسل تجريبي لتوضيح شاشة المواسم والحلقات.", null, null, 8.0, "2026", "tv", true)
    )
}
