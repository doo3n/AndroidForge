# KRA Cinema — Android TV prototype 0.1.0

A starter Android TV media player prototype written in Kotlin + Jetpack Compose and AndroidX Media3.

## Included
- Android TV launcher intent (`LEANBACK_LAUNCHER`) and touchscreen-not-required declaration.
- D-pad focusable actions and video tiles.
- USB/storage folder picker using Android Storage Access Framework.
- Lists video files in the selected folder and plays a selected file with Media3 ExoPlayer.
- Network-library tile reserved for a later SMB / media-server implementation.

## Build requirements
- JDK 17 or newer (JDK 21 is suitable)
- Android SDK Platform 35 and Build Tools 35.0.0
- Gradle 8.11.1+ (project uses Android Gradle Plugin 8.9.2)

Build from this directory:

```bash
gradle assembleDebug
```

APK output after a successful build:
`app/build/outputs/apk/debug/app-debug.apk`

Install using Android TV's package installer or `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

## Prototype limitations
- The USB picker currently scans the selected folder's immediate children, not nested folders.
- Playback depends on the Android TV device's supported codecs and containers.
- Network library browsing is a placeholder and is not implemented yet.
- This source package has not been compiled in the current environment because Android SDK / Gradle are absent and outbound downloads are unavailable. Do not treat it as a verified APK.
