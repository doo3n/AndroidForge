# KRA Cinema — Android TV Prototype

Prototype Android TV media player project.

## Build compatibility

The root Android Gradle Plugin is pinned to **8.7.3** to remain compatible with the Gradle 8.9 toolchain used by the current AndroidForge runner. Kotlin plugins remain at 2.1.10.

## Build

Run from this directory with a compatible Android SDK and Gradle installation:

```bash
gradle assembleDebug
```

Expected debug APK path:

`app/build/outputs/apk/debug/app-debug.apk`

This is a prototype. USB storage access and playback behavior still need testing on the target Android TV model.
