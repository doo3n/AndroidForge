package com.kra.cinema

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.viewinterop.AndroidView
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.launch


private var currentLanguage by mutableStateOf("ar")
private val translations = mapOf(
    "أدخل بيانات TMDB لعرض أحدث الأفلام والمسلسلات" to "Enter your TMDB details to browse the latest movies and series",
    "لم نعثر على فيديوهات في المجلد المحدد" to "No videos were found in the selected folder",
    "أضف TMDB Read Access Token من الإعدادات لتفعيل الكتالوج" to "Add a TMDB Read Access Token in Settings to enable the catalog",
    "تم تحديث الكتالوج من TMDB" to "Catalog updated from TMDB",
    "البداية" to "Beginning",
    "حلقة تجريبية لعرض شكل قائمة الحلقات." to "A sample episode to demonstrate the episode list.",
    "خط جديد" to "A New Line",
    "حلقة تجريبية ثانية." to "Second sample episode.",
    "داخل المؤسسة" to "Inside the Institution",
    "حلقة تجريبية ثالثة." to "Third sample episode.",
    "تشغيل رابط بث" to "Play Stream URL",
    "رابط الفيديو HLS / MP4" to "HLS / MP4 video URL",
    "بث مباشر" to "Live Stream",
    "تشغيل" to "Play",
    "إلغاء" to "Cancel",
    "البحث في TMDB" to "Search TMDB",
    "اسم الفيلم أو المسلسل" to "Movie or series title",
    "بحث" to "Search",
    "⌕  البحث" to "⌕  Search",
    "⚙  الإعدادات" to "⚙  Settings",
    "عرض تجريبي · بيانات مؤقتة" to "DEMO · Sample data",
    "مسلسل مميز" to "Featured Series",
    "فيلم مميز" to "Featured Movie",
    "مسلسل" to "Series",
    "فيلم" to "Movie",
    "اكتشف تفاصيل العمل ومعلوماته وحلقاته أو الأعمال المشابهة." to "Explore details, information, episodes, and similar titles.",
    "التفاصيل" to "Details",
    "سينما بيتك" to "Your Home Cinema",
    "أفلامك ومسلسلاتك في مكان واحد" to "Your movies and series, all in one place",
    "جارٍ تحميل الكتالوج…" to "Loading catalog…",
    "أحدث الأفلام والمسلسلات · بيانات مؤقتة" to "Latest Movies & Series · Sample Data",
    "أحدث الأفلام والمسلسلات" to "Latest Movies & Series",
    "ستظهر الأعمال هنا بعد إضافة TMDB Read Access Token من الإعدادات." to "Titles will appear here after you add a TMDB Read Access Token in Settings.",
    "مصادر المشاهدة" to "Playback Sources",
    "USB / التخزين المحلي" to "USB / Local Storage",
    "اختيار مجلد الفيديو" to "Choose Video Folder",
    "مكتبة الشبكة" to "Network Library",
    "فتح مزود ملفات الشبكة" to "Open Network File Provider",
    "رابط بث مباشر" to "Stream URL",
    "HLS / MP4 عبر الإنترنت" to "HLS / MP4 over the internet",
    "تشغيل الملف" to "Play File",
    "بيانات الأعمال والتقييمات والصور عبر TMDB · تشغيل الفيديو عبر Media3" to "Titles, ratings and artwork via TMDB · Video playback via Media3",
    "‹  رجوع" to "‹  Back",
    "بيانات تجريبية مؤقتة · سيتم استبدالها ببيانات TMDB بعد إضافة المفتاح" to "Temporary sample data · TMDB data will appear after adding your API token",
    "لا يوجد وصف متاح لهذا العمل." to "No overview is available for this title.",
    "الموسم الأول · الحلقات" to "Season 1 · Episodes",
    "هذه حلقات توضيحية وليست بيانات فعلية." to "These are sample episodes, not actual episode data.",
    "جارٍ تحميل الحلقات…" to "Loading episodes…",
    "لا توجد حلقات محملة. تحقق من اتصال TMDB." to "No episodes loaded. Check your TMDB connection.",
    "ملف محلي مطابق" to "Matching local file",
    "ملاحظة: TMDB يوفّر بيانات الحلقات فقط؛ مصدر الفيديو يُختار من ملفاتك أو رابط البث." to "Note: TMDB provides episode metadata only; choose the video source from your files or a stream URL.",
    "أفلام مشابهة" to "Similar Movies",
    "ستظهر الاقتراحات الحقيقية بعد ربط TMDB." to "Real recommendations will appear after connecting TMDB.",
    "جارٍ تحميل الاقتراحات…" to "Loading recommendations…",
    "إعدادات الربط" to "Connection Settings",
    "TMDB — بيانات الأفلام والمسلسلات والتقييمات" to "TMDB — Movie, series and rating data",
    "OpenSubtitles — البحث عن الترجمات وتنزيلها" to "OpenSubtitles — Find and download subtitles",
    "تُحفظ المفاتيح محلياً على الجهاز. لا تضع مفاتيحك داخل ملفات المشروع أو GitHub." to "Keys are stored locally on this device. Do not put API keys in project files or GitHub.",
    "حفظ الإعدادات" to "Save Settings",
    "تمت إضافة ملف الترجمة" to "Subtitle file added",
    "صوت" to "Audio",
    "ترجمة" to "Subtitle",
    "غير محدد" to "Unspecified",
    "رجوع" to "Back",
    "الصوت" to "Audio",
    "الترجمة" to "Subtitles",
    "اختيار الدبلجة الصوتية" to "Choose Audio Track",
    "إيقاف الترجمة" to "Turn Subtitles Off",
    "البحث عن ترجمة عبر API" to "Search Subtitles via API",
    "رفع ملف ترجمة من الجهاز" to "Add Subtitle File from Device",
    "إغلاق" to "Close",
    "لغة ملف الترجمة" to "Subtitle File Language",
    "العربية" to "Arabic",
    "البحث عن ترجمة" to "Search Subtitles",
    "جارٍ البحث…" to "Searching…",
    "بحث عربي / إنجليزي" to "Search Arabic / English",
    "أضف OpenSubtitles API Key من الإعدادات أولاً." to "Add your OpenSubtitles API Key in Settings first.",
    "تم تنزيل الترجمة وإضافتها" to "Subtitle downloaded and added",
    "لا توجد مسارات متاحة لهذا الملف." to "No tracks are available for this file.",
    "أدخل TMDB Read Access Token أولاً" to "Enter a TMDB Read Access Token first",
    "لم يتم العثور على نتائج للفيلم التجريبي" to "No results were found for the sample movie",
    "تم جلب بيانات Oppenheimer من TMDB" to "Oppenheimer data was fetched from TMDB",
    "أنشئ API Read Access Token من حساب TMDB ثم الصقه هنا. يدعم التطبيق Bearer Token (وليس رابط صفحة الإعدادات)." to "Create an API Read Access Token in your TMDB account and paste it here. The app uses a Bearer Token, not the settings page URL.",
    "فتح صفحة TMDB API" to "Open TMDB API Settings",
    "جلب فيلم تجريبي: Oppenheimer" to "Fetch sample movie: Oppenheimer",
    "سيجلب الاختبار العنوان والوصف والتقييم وسنة الإصدار والملصق والخلفية من TMDB لعرضها داخل الكتالوج." to "This test fetches the title, overview, rating, release year, poster and backdrop from TMDB for the catalog."
)
private fun tx(arabic: String): String = if (currentLanguage == "en") translations[arabic] ?: arabic else arabic

private val Night = Color(0xFF070B12)
private val Panel = Color(0xFF111C2A)
private val Panel2 = Color(0xFF17283A)
private val Blue = Color(0xFF168BDF)
private val Cyan = Color(0xFF36C7E8)
private val Muted = Color(0xFF9EADBD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinemaApp() }
    }
}

private data class VideoFile(val title: String, val uri: Uri)
private data class PlaybackSource(val title: String, val uri: Uri)
private data class TrackOption(val group: Tracks.Group, val index: Int, val label: String, val language: String?)

@Composable
private fun CinemaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("kra_cinema_settings", 0) }
    var language by remember { mutableStateOf(prefs.getString("language", "ar") ?: "ar") }
    SideEffect { currentLanguage = language }
    var tmdbToken by remember { mutableStateOf(prefs.getString("tmdb_token", "") ?: "") }
    var subtitlesKey by remember { mutableStateOf(prefs.getString("opensubtitles_key", "") ?: "") }
    var videos by remember { mutableStateOf(emptyList<VideoFile>()) }
    var selected by remember { mutableStateOf<CatalogItem?>(null) }
    var playing by remember { mutableStateOf<PlaybackSource?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var urlDialog by remember { mutableStateOf(false) }
    var searchDialog by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    var catalog by remember { mutableStateOf(DemoCatalog.items) }
    var searchResults by remember { mutableStateOf<List<CatalogItem>>(emptyList()) }
    var similar by remember { mutableStateOf<List<CatalogItem>>(emptyList()) }
    var episodes by remember { mutableStateOf<List<EpisodeItem>>(emptyList()) }
    var status by remember { mutableStateOf(tx("أدخل بيانات TMDB لعرض أحدث الأفلام والمسلسلات")) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Remote Back behaves as in a TV app: pop the current screen first.
    // At the home screen, consume Back so the app is not accidentally closed.
    BackHandler(enabled = true) {
        when {
            urlDialog -> urlDialog = false
            searchDialog -> searchDialog = false
            playing != null -> playing = null
            settingsOpen -> settingsOpen = false
            selected != null -> selected = null
            else -> Unit
        }
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val root = DocumentFile.fromTreeUri(context, treeUri)
                val found = root?.listFiles()?.filter { file ->
                    file.isFile && (file.type?.startsWith("video/") == true || file.name?.substringAfterLast('.', "")?.lowercase() in listOf("mp4", "mkv", "avi", "mov", "m4v", "webm", "ts"))
                }?.map { VideoFile(it.name ?: "Video", it.uri) }.orEmpty()
                videos = found
                status = if (found.isEmpty()) tx("لم نعثر على فيديوهات في المجلد المحدد") else tx("تم العثور على ${found.size} ملف فيديو")
            } catch (e: Exception) { status = tx("تعذر قراءة المجلد: ${e.localizedMessage}") }
        }
    }

    fun refreshCatalog() {
        if (tmdbToken.isBlank()) { status = tx("أضف TMDB Read Access Token من الإعدادات لتفعيل الكتالوج"); return }
        scope.launch {
            loading = true
            try {
                catalog = TmdbService(tmdbToken, if (language == "ar") "ar-SA" else "en-US").trending()
                status = tx("تم تحديث الكتالوج من TMDB")
            } catch (e: Exception) { status = tx("تعذر الاتصال بـ TMDB: ${e.message}") }
            loading = false
        }
    }

    fun openItem(item: CatalogItem) {
        selected = item
        similar = emptyList()
        episodes = if (item.isDemo && item.isSeries) listOf(
            EpisodeItem(1, tx("البداية"), tx("حلقة تجريبية لعرض شكل قائمة الحلقات."), null),
            EpisodeItem(2, tx("خط جديد"), tx("حلقة تجريبية ثانية."), null),
            EpisodeItem(3, tx("داخل المؤسسة"), tx("حلقة تجريبية ثالثة."), null)
        ) else emptyList()
    }

    LaunchedEffect(tmdbToken, language) { if (tmdbToken.isNotBlank()) refreshCatalog() }

    CompositionLocalProvider(LocalLayoutDirection provides if (language == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Cyan, background = Night, surface = Panel, onPrimary = Color.White),
        typography = Typography()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10243A), Night)))) {
            when {
                playing != null -> PlayerScreen(
                    source = playing!!,
                    apiKey = subtitlesKey,
                    onBack = { playing = null },
                    onStatus = { status = it }
                )
                settingsOpen -> SettingsScreen(
                    tmdbToken = tmdbToken,
                    subtitlesKey = subtitlesKey,
                    onSave = { tmdb, subs ->
                        tmdbToken = tmdb.trim(); subtitlesKey = subs.trim()
                        prefs.edit().putString("tmdb_token", tmdbToken).putString("opensubtitles_key", subtitlesKey).apply()
                        settingsOpen = false
                    },
                    onTestTmdb = { token ->
                        if (token.isBlank()) {
                            status = tx("أدخل TMDB Read Access Token أولاً")
                        } else {
                            tmdbToken = token.trim()
                            prefs.edit().putString("tmdb_token", tmdbToken).apply()
                            scope.launch {
                                loading = true
                                try {
                                    val sample = TmdbService(token.trim(), if (language == "ar") "ar-SA" else "en-US").sampleMovie()
                                    catalog = listOfNotNull(sample)
                                    status = if (sample == null) tx("لم يتم العثور على نتائج للفيلم التجريبي") else tx("تم جلب بيانات Oppenheimer من TMDB")
                                } catch (e: Exception) {
                                    status = tx("تعذر الاتصال بـ TMDB: ${e.message}")
                                }
                                loading = false
                                settingsOpen = false
                            }
                        }
                    },
                    onBack = { settingsOpen = false }
                )
                selected != null -> DetailsScreen(
                    item = selected!!,
                    similar = similar,
                    episodes = episodes,
                    loading = loading,
                    onBack = { selected = null },
                    onPlay = { playing = PlaybackSource(selected!!.title, it) },
                    onSelectSimilar = { openItem(it) },
                    onLoadDetails = {
                        val item = selected!!
                        scope.launch {
                            loading = true
                            try {
                                if (!item.isDemo) {
                                    if (item.isSeries) episodes = TmdbService(tmdbToken, if (language == "ar") "ar-SA" else "en-US").episodes(item)
                                    else similar = TmdbService(tmdbToken, if (language == "ar") "ar-SA" else "en-US").similar(item)
                                }
                            } catch (e: Exception) { status = tx("تعذر تحميل التفاصيل: ${e.message}") }
                            loading = false
                        }
                    },
                    localVideos = videos
                )
                else -> HomeScreen(
                    catalog = catalog,
                    videos = videos,
                    status = status,
                    loading = loading,
                    onSelect = { openItem(it) },
                    onUsb = { folderPicker.launch(null) },
                    onNetwork = { folderPicker.launch(null) },
                    onStream = { urlDialog = true },
                    onSettings = { settingsOpen = true },
                    onSearch = { searchDialog = true },
                    onToggleLanguage = {
                        language = if (language == "ar") "en" else "ar"
                        prefs.edit().putString("language", language).apply()
                    },
                    onPlayLocal = { playing = PlaybackSource(it.title, it.uri) }
                )
            }
        }
    }
    }

    if (urlDialog) {
        var url by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { urlDialog = false }, containerColor = Panel,
            title = { Text(tx("تشغيل رابط بث"), color = Color.White) },
            text = { OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text(tx("رابط الفيديو HLS / MP4")) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (url.startsWith("http://") || url.startsWith("https://")) { playing = PlaybackSource(tx("بث مباشر"), Uri.parse(url)); urlDialog = false } }) { Text(tx("تشغيل")) } },
            dismissButton = { TextButton(onClick = { urlDialog = false }) { Text(tx("إلغاء")) } })
    }
    if (searchDialog) {
        var query by remember { mutableStateOf(searchText) }
        AlertDialog(onDismissRequest = { searchDialog = false }, containerColor = Panel,
            title = { Text(tx("البحث في TMDB"), color = Color.White) },
            text = { OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text(tx("اسم الفيلم أو المسلسل")) }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                searchText = query; searchDialog = false
                if (tmdbToken.isNotBlank() && query.isNotBlank()) scope.launch {
                    loading = true
                    try { searchResults = TmdbService(tmdbToken, if (language == "ar") "ar-SA" else "en-US").search(query); catalog = searchResults }
                    catch (e: Exception) { status = tx("فشل البحث: ${e.message}") }
                    loading = false
                }
            }) { Text(tx("بحث")) } }, dismissButton = { TextButton(onClick = { searchDialog = false }) { Text(tx("إلغاء")) } })
    }

}

@Composable
private fun HomeScreen(
    catalog: List<CatalogItem>, videos: List<VideoFile>, status: String, loading: Boolean,
    onSelect: (CatalogItem) -> Unit, onUsb: () -> Unit, onNetwork: () -> Unit,
    onStream: () -> Unit, onSettings: () -> Unit, onSearch: () -> Unit, onToggleLanguage: () -> Unit, onPlayLocal: (VideoFile) -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 42.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("KRA", color = Cyan, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text(" CINEMA", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onSearch) { Text(tx("⌕  البحث"), color = Color.White) }
            TextButton(onClick = onSettings) { Text(tx("⚙  الإعدادات"), color = Color.White) }
            TextButton(onClick = onToggleLanguage) { Text(if (currentLanguage == "ar") "English" else "العربية", color = Cyan) }
        }
        Spacer(Modifier.height(24.dp))
        val hero = catalog.firstOrNull()
        if (hero != null) {
            Box(Modifier.fillMaxWidth().height(300.dp).background(Panel, RoundedCornerShape(22.dp))) {
                hero.backdropUrl?.let { AsyncImage(model = it, contentDescription = hero.title, modifier = Modifier.fillMaxSize()) }
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Night.copy(alpha = .96f), Night.copy(alpha = .62f), Color.Transparent))))
                Column(Modifier.align(Alignment.CenterStart).widthIn(max = 620.dp).padding(28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (hero.isDemo) tx("عرض تجريبي · بيانات مؤقتة") else if (hero.isSeries) tx("مسلسل مميز") else tx("فيلم مميز"), color = Cyan, fontSize = 14.sp)
                    Text(hero.title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text("★ ${"%.1f".format(hero.rating)}   ${hero.year}   ${if (hero.isSeries) tx("مسلسل") else tx("فيلم")}", color = Color.White, fontSize = 15.sp)
                    Text(hero.overview.ifBlank { tx("اكتشف تفاصيل العمل ومعلوماته وحلقاته أو الأعمال المشابهة.") }, color = Color(0xFFDCE7F2), maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Button(onClick = { onSelect(hero) }) { Text(tx("التفاصيل")) }
                }
            }
        } else {
            Box(Modifier.fillMaxWidth().height(220.dp).background(Panel, RoundedCornerShape(22.dp)).padding(28.dp), contentAlignment = Alignment.CenterStart) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tx("سينما بيتك"), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                    Text(tx("أفلامك ومسلسلاتك في مكان واحد"), color = Muted, fontSize = 18.sp)
                    Text(if (loading) tx("جارٍ تحميل الكتالوج…") else status, color = Cyan, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text(if (catalog.firstOrNull()?.isDemo == true) tx("أحدث الأفلام والمسلسلات · بيانات مؤقتة") else tx("أحدث الأفلام والمسلسلات"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (catalog.isEmpty()) Text(tx("ستظهر الأعمال هنا بعد إضافة TMDB Read Access Token من الإعدادات."), color = Muted)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(catalog, key = { "${it.mediaType}-${it.id}" }) { item -> CatalogCard(item, onClick = { onSelect(item) }) }
        }
        Spacer(Modifier.height(24.dp))
        Text(tx("مصادر المشاهدة"), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile(tx("USB / التخزين المحلي"), tx("اختيار مجلد الفيديو"), onUsb, Modifier.weight(1f))
            ActionTile(tx("مكتبة الشبكة"), tx("فتح مزود ملفات الشبكة"), onNetwork, Modifier.weight(1f))
            ActionTile(tx("رابط بث مباشر"), tx("HLS / MP4 عبر الإنترنت"), onStream, Modifier.weight(1f))
        }
        if (videos.isNotEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text(tx("ملفاتك المحلية (${videos.size})"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(videos) { video -> ActionTile(video.title, tx("تشغيل الملف"), { onPlayLocal(video) }, Modifier.width(230.dp)) }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(tx("بيانات الأعمال والتقييمات والصور عبر TMDB · تشغيل الفيديو عبر Media3"), color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun CatalogCard(item: CatalogItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, modifier = Modifier.width(150.dp).height(245.dp).onFocusChanged { focused = it.isFocused },
        color = Panel, shape = RoundedCornerShape(12.dp), border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) Cyan else Color(0xFF29435A))) {
        Column {
            Box(Modifier.weight(1f).fillMaxWidth().background(Panel2)) {
                item.posterUrl?.let { AsyncImage(model = it, contentDescription = item.title, modifier = Modifier.fillMaxSize()) }
                Text("★ ${"%.1f".format(item.rating)}", Modifier.align(Alignment.BottomStart).padding(7.dp).background(Night.copy(alpha = .85f), RoundedCornerShape(8.dp)).padding(horizontal = 7.dp, vertical = 4.dp), color = Color(0xFFFFD45A), fontSize = 11.sp)
            }
            Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.year} · ${if (item.isSeries) tx("مسلسل") else tx("فيلم")}", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    var focused by remember { mutableStateOf(false) }
    Surface(onClick = onClick, modifier = modifier.height(88.dp).onFocusChanged { focused = it.isFocused }, shape = RoundedCornerShape(14.dp),
        color = if (focused) Color(0xFF123F66) else Panel, border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) Cyan else Color(0xFF2A4055))) {
        Column(Modifier.padding(horizontal = 15.dp, vertical = 12.dp), verticalArrangement = Arrangement.Center) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun DetailsScreen(
    item: CatalogItem, similar: List<CatalogItem>, episodes: List<EpisodeItem>, loading: Boolean,
    onBack: () -> Unit, onPlay: (Uri) -> Unit, onSelectSimilar: (CatalogItem) -> Unit,
    onLoadDetails: () -> Unit, localVideos: List<VideoFile>
) {
    LaunchedEffect(item.id) { onLoadDetails() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(34.dp)) {
        TextButton(onClick = onBack) { Text(tx("‹  رجوع"), color = Color.White) }
        Box(Modifier.fillMaxWidth().height(260.dp).background(Panel, RoundedCornerShape(18.dp))) {
            item.backdropUrl?.let { AsyncImage(model = it, contentDescription = item.title, modifier = Modifier.fillMaxSize()) }
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Night.copy(alpha = .97f), Night.copy(alpha = .58f), Color.Transparent))))
            Column(Modifier.align(Alignment.CenterStart).widthIn(max = 650.dp).padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(item.title, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                if (item.isDemo) Text(tx("بيانات تجريبية مؤقتة · سيتم استبدالها ببيانات TMDB بعد إضافة المفتاح"), color = Color(0xFFFFC66D), fontSize = 12.sp)
                Text("★ ${"%.1f".format(item.rating)}   ${item.year}   ${if (item.isSeries) tx("مسلسل") else tx("فيلم")}", color = Cyan)
                Text(item.overview.ifBlank { tx("لا يوجد وصف متاح لهذا العمل.") }, color = Color.White, maxLines = 4, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(22.dp))
        if (item.isSeries) {
            Text(tx("الموسم الأول · الحلقات"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (item.isDemo) Text(tx("هذه حلقات توضيحية وليست بيانات فعلية."), color = Color(0xFFFFC66D), fontSize = 11.sp)
            if (loading) Text(tx("جارٍ تحميل الحلقات…"), color = Muted)
            if (episodes.isEmpty() && !loading) Text(tx("لا توجد حلقات محملة. تحقق من اتصال TMDB."), color = Muted)
            episodes.forEach { episode ->
                val episodeTag = "S01E${episode.number.toString().padStart(2, '0')}"
                val matchingVideo = localVideos.firstOrNull { it.title.contains(episodeTag, ignoreCase = true) || it.title.contains(tx("الحلقة ${episode.number}")) }
                Surface(onClick = { matchingVideo?.let { onPlay(it.uri) } }, enabled = matchingVideo != null, color = Panel, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (matchingVideo != null) "▶" else "${episode.number}", color = if (matchingVideo != null) Cyan else Muted, fontSize = 22.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tx("الحلقة ${episode.number}: ${episode.name}"), color = Color.White, fontWeight = FontWeight.Bold)
                            Text(episode.overview.ifBlank { if (matchingVideo != null) tx("ملف محلي مطابق") else tx("بيانات الحلقة من TMDB · أضف ملفاً باسم S01E${episode.number.toString().padStart(2, '0')} لتشغيلها مباشرة") }, color = Muted, maxLines = 2, fontSize = 12.sp)
                        }
                    }
                }
            }
            Text(tx("ملاحظة: TMDB يوفّر بيانات الحلقات فقط؛ مصدر الفيديو يُختار من ملفاتك أو رابط البث."), color = Muted, fontSize = 11.sp)
        } else {
            Text(tx("أفلام مشابهة"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (item.isDemo) Text(tx("ستظهر الاقتراحات الحقيقية بعد ربط TMDB."), color = Muted, fontSize = 11.sp)
            if (loading) Text(tx("جارٍ تحميل الاقتراحات…"), color = Muted)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(similar, key = { it.id }) { CatalogCard(it) { onSelectSimilar(it) } } }
        }
    }
}

@Composable
private fun SettingsScreen(
    tmdbToken: String, subtitlesKey: String,
    onSave: (String, String) -> Unit,
    onTestTmdb: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var tmdb by remember { mutableStateOf(tmdbToken) }
    var subtitles by remember { mutableStateOf(subtitlesKey) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(42.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onBack) { Text(tx("‹  رجوع"), color = Color.White) }
        Text(tx("إعدادات الربط"), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(tx("TMDB — بيانات الأفلام والمسلسلات والتقييمات والصور"), color = Cyan, fontWeight = FontWeight.Bold)
        Text(tx("أنشئ API Read Access Token من حساب TMDB ثم الصقه هنا. يدعم التطبيق Bearer Token (وليس رابط صفحة الإعدادات)."), color = Muted, fontSize = 12.sp)
        OutlinedTextField(
            value = tmdb, onValueChange = { tmdb = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("TMDB API Read Access Token") }, singleLine = true
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.themoviedb.org/settings/api"))
                context.startActivity(intent)
            }) { Text(tx("فتح صفحة TMDB API"), color = Cyan) }
            Button(onClick = { onTestTmdb(tmdb) }, enabled = tmdb.isNotBlank()) {
                Text(tx("جلب فيلم تجريبي: Oppenheimer"))
            }
        }
        Text(tx("سيجلب الاختبار العنوان والوصف والتقييم وسنة الإصدار والملصق والخلفية من TMDB لعرضها داخل الكتالوج."), color = Muted, fontSize = 12.sp)
        Text(tx("OpenSubtitles — البحث عن الترجمات وتنزيلها"), color = Cyan, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = subtitles, onValueChange = { subtitles = it }, modifier = Modifier.fillMaxWidth(), label = { Text("OpenSubtitles API Key") }, singleLine = true)
        Text(tx("تُحفظ المفاتيح محلياً على الجهاز. لا تضع مفاتيحك داخل ملفات المشروع أو GitHub."), color = Muted, fontSize = 12.sp)
        Button(onClick = { onSave(tmdb, subtitles) }) { Text(tx("حفظ الإعدادات")) }
    }
}

@Composable
private fun PlayerScreen(source: PlaybackSource, apiKey: String, onBack: () -> Unit, onStatus: (String) -> Unit) {
    val context = LocalContext.current
    var player by remember(source.uri) { mutableStateOf<ExoPlayer?>(null) }
    var tracks by remember { mutableStateOf(emptyList<TrackOption>()) }
    var showAudio by remember { mutableStateOf(false) }
    var showSubtitles by remember { mutableStateOf(false) }
    var showSubtitleSearch by remember { mutableStateOf(false) }
    var showManualLanguage by remember { mutableStateOf(false) }
    var manualSubtitleLanguage by remember { mutableStateOf("ara") }
    var subtitleResults by remember { mutableStateOf(emptyList<SubtitleResult>()) }
    var subtitleQuery by remember { mutableStateOf(source.title) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            attachSubtitle(player, source.uri, uri, manualSubtitleLanguage)
            onStatus(tx("تمت إضافة ملف الترجمة"))
        }
    }

    DisposableEffect(source.uri) {
        val exo = ExoPlayer.Builder(context).build()
        exo.setMediaItem(MediaItem.fromUri(source.uri)); exo.prepare(); exo.playWhenReady = true
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onTracksChanged(currentTracks: Tracks) {
                tracks = currentTracks.groups.flatMap { group ->
                    if (group.type != C.TRACK_TYPE_AUDIO && group.type != C.TRACK_TYPE_TEXT) emptyList()
                    else (0 until group.length).filter { group.isTrackSupported(it) }.map { index ->
                        val format = group.getTrackFormat(index)
                        val lang = format.language
                        TrackOption(group, index, "${if (group.type == C.TRACK_TYPE_AUDIO) tx("صوت") else tx("ترجمة")} · ${lang ?: tx("غير محدد")} · ${format.label ?: tx("مسار ${index + 1}")}", lang)
                    }
                }
            }
        }
        exo.addListener(listener)
        player = exo
        onDispose { exo.removeListener(listener); exo.release(); player = null }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(tx("رجوع"), color = Color.White) }
            Text(source.title, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
            TextButton(onClick = { showAudio = true }) { Text(tx("الصوت"), color = Cyan) }
            TextButton(onClick = { showSubtitles = true }) { Text(tx("الترجمة"), color = Cyan) }
        }
        player?.let { exo -> AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = exo; useController = true } }, modifier = Modifier.fillMaxSize()) }
    }

    if (showAudio) TrackDialog(tx("اختيار الدبلجة الصوتية"), tracks.filter { it.group.type == C.TRACK_TYPE_AUDIO }, onDismiss = { showAudio = false }, onChoose = { option ->
        player?.let { exo -> exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_AUDIO).addOverride(androidx.media3.common.TrackSelectionOverride(option.group.mediaTrackGroup, listOf(option.index))).build() }
        showAudio = false
    })
    if (showSubtitles) AlertDialog(onDismissRequest = { showSubtitles = false }, containerColor = Panel,
        title = { Text(tx("الترجمة"), color = Color.White) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tx("المسارات المضمنة: ${tracks.count { it.group.type == C.TRACK_TYPE_TEXT }}"), color = Muted)
            TextButton(onClick = { player?.let { exo -> exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }; showSubtitles = false }) { Text(tx("إيقاف الترجمة")) }
            TextButton(onClick = { showSubtitles = false; showSubtitleSearch = true }) { Text(tx("البحث عن ترجمة عبر API")) }
            TextButton(onClick = { showSubtitles = false; showManualLanguage = true }) { Text(tx("رفع ملف ترجمة من الجهاز")) }
            tracks.filter { it.group.type == C.TRACK_TYPE_TEXT }.forEach { option -> TextButton(onClick = {
                player?.let { exo -> exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).addOverride(androidx.media3.common.TrackSelectionOverride(option.group.mediaTrackGroup, listOf(option.index))).build() }
                showSubtitles = false
            }) { Text(option.label) } }
        } }, confirmButton = { TextButton(onClick = { showSubtitles = false }) { Text(tx("إغلاق")) } })

    if (showManualLanguage) AlertDialog(onDismissRequest = { showManualLanguage = false }, containerColor = Panel,
        title = { Text(tx("لغة ملف الترجمة"), color = Color.White) },
        text = { Column {
            TextButton(onClick = { manualSubtitleLanguage = "ara"; showManualLanguage = false; subtitlePicker.launch(arrayOf("application/x-subrip", "text/plain", "application/octet-stream", "text/vtt")) }) { Text(tx("العربية")) }
            TextButton(onClick = { manualSubtitleLanguage = "eng"; showManualLanguage = false; subtitlePicker.launch(arrayOf("application/x-subrip", "text/plain", "application/octet-stream", "text/vtt")) }) { Text("English") }
        } }, confirmButton = { TextButton(onClick = { showManualLanguage = false }) { Text(tx("إلغاء")) } })

    if (showSubtitleSearch) Dialog(onDismissRequest = { showSubtitleSearch = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(.82f).heightIn(max = 560.dp), color = Panel, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tx("البحث عن ترجمة"), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = subtitleQuery, onValueChange = { subtitleQuery = it }, modifier = Modifier.fillMaxWidth(), label = { Text(tx("اسم الفيلم أو المسلسل")) })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = apiKey.isNotBlank() && !busy, onClick = {
                        scope.launch {
                            busy = true
                            try { subtitleResults = OpenSubtitlesService(apiKey).search(subtitleQuery, "", "ara,eng"); onStatus(tx("نتائج الترجمة: ${subtitleResults.size}")) }
                            catch (e: Exception) { onStatus(tx("فشل البحث عن الترجمة: ${e.message}")) }
                            busy = false
                        }
                    }) { Text(if (busy) tx("جارٍ البحث…") else tx("بحث عربي / إنجليزي")) }
                    TextButton(onClick = { showSubtitleSearch = false }) { Text(tx("إغلاق")) }
                }
                if (apiKey.isBlank()) Text(tx("أضف OpenSubtitles API Key من الإعدادات أولاً."), color = Color(0xFFFFC66D))
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                    subtitleResults.forEach { result ->
                        Surface(onClick = {
                            scope.launch {
                                busy = true
                                try {
                                    val uri = OpenSubtitlesService(apiKey).download(context, result.fileId)
                                    attachSubtitle(player, source.uri, uri, result.language)
                                    onStatus(tx("تم تنزيل الترجمة وإضافتها"))
                                    showSubtitleSearch = false
                                } catch (e: Exception) { onStatus(tx("تعذر تنزيل الترجمة: ${e.message}")) }
                                busy = false
                            }
                        }, color = Panel2, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("${result.language.uppercase()} · ${result.fileName}", color = Color.White, fontWeight = FontWeight.Bold)
                                Text(tx("${result.release} · ${result.downloads} تنزيل"), color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackDialog(title: String, options: List<TrackOption>, onDismiss: () -> Unit, onChoose: (TrackOption) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(title, color = Color.White) },
        text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
            if (options.isEmpty()) Text(tx("لا توجد مسارات متاحة لهذا الملف."), color = Muted)
            options.forEach { option -> TextButton(onClick = { onChoose(option) }) { Text(option.label, color = Color.White) } }
        } }, confirmButton = { TextButton(onClick = onDismiss) { Text(tx("إغلاق")) } })
}

private fun attachSubtitle(player: ExoPlayer?, videoUri: Uri, subtitleUri: Uri, language: String) {
    val mime = when (subtitleUri.lastPathSegment?.substringAfterLast('.', "")?.lowercase()) {
        "ass" -> MimeTypes.TEXT_SSA
        "ssa" -> MimeTypes.TEXT_SSA
        "vtt" -> MimeTypes.TEXT_VTT
        else -> MimeTypes.APPLICATION_SUBRIP
    }
    val config = MediaItem.SubtitleConfiguration.Builder(subtitleUri).setMimeType(mime).setLanguage(language).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
    player?.let { exo ->
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        exo.setMediaItem(MediaItem.Builder().setUri(videoUri).setSubtitleConfigurations(listOf(config)).build())
        exo.prepare()
        exo.playWhenReady = true
    }
}
